"""
Seed script to populate demo data for SLNSVM School Management System.

Run with: python seed_demo_data.py
"""

import sys
import os

# Add the backend directory to the path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from datetime import date, time
from app.core.database import SessionLocal, engine, Base
from app.core.security import get_password_hash
from app.models.user import User, UserRole
from app.models.student import Student
from app.models.parent import Parent
from app.models.teacher import Teacher
from app.models.admin import Admin
from app.models.academic import Class, Subject, Timetable, DayOfWeek
from app.models.notice import Notice


def seed_database():
    """Seed the database with demo data."""
    db = SessionLocal()

    try:
        print("🌱 Starting database seeding...")

        # Check if data already exists
        existing_users = db.query(User).count()
        if existing_users > 0:
            print(f"⚠️  Database already has {existing_users} users. Skipping seed.")
            print("\nExisting demo credentials:")
            users = db.query(User).all()
            for user in users:
                print(f"  - {user.email} ({user.role.value})")
            return

        # Create demo password (same for all demo accounts)
        demo_password = get_password_hash("demo123")

        # ==================== ADMIN ====================
        print("\n📋 Creating Admin users...")
        admin_user = User(
            email="admin@slnsvm.com",
            password_hash=demo_password,
            role=UserRole.ADMIN,
            is_active=True
        )
        db.add(admin_user)
        db.flush()

        admin_profile = Admin(
            user_id=admin_user.id,
            name="Principal Admin",
            designation="Principal",
            phone="+91-9876543210"
        )
        db.add(admin_profile)

        # ==================== CLASSES ====================
        print("📚 Creating Classes...")
        classes = []
        for i in range(1, 11):
            for section in ['A', 'B']:
                class_obj = Class(
                    name=f"Class {i}",
                    section=section,
                    academic_year="2024-25",
                    room_number=f"Room {i}{section}"
                )
                db.add(class_obj)
                classes.append(class_obj)
        db.flush()

        # Get specific classes for demo
        class_10_a = db.query(Class).filter(Class.name == "Class 10", Class.section == "A").first()
        class_8_b = db.query(Class).filter(Class.name == "Class 8", Class.section == "B").first()

        # ==================== SUBJECTS ====================
        print("📖 Creating Subjects...")
        subject_names = [
            ("Mathematics", "MATH10"),
            ("Science", "SCI10"),
            ("English", "ENG10"),
            ("Hindi", "HIN10"),
            ("Social Science", "SST10"),
            ("Computer Science", "CS10"),
        ]
        subjects = []
        for name, code in subject_names:
            subject = Subject(
                name=name,
                code=code,
                class_id=class_10_a.id if class_10_a else None,
                description=f"{name} for Class 10"
            )
            db.add(subject)
            subjects.append(subject)
        db.flush()

        # ==================== TEACHERS ====================
        print("👨‍🏫 Creating Teacher users...")
        teachers_data = [
            ("teacher@slnsvm.com", "Rajesh Kumar", "T001", "M.Sc. Mathematics", 10),
            ("teacher2@slnsvm.com", "Priya Sharma", "T002", "M.Sc. Physics", 8),
            ("teacher3@slnsvm.com", "Amit Singh", "T003", "M.A. English", 5),
        ]

        for email, name, emp_id, qual, exp in teachers_data:
            teacher_user = User(
                email=email,
                password_hash=demo_password,
                role=UserRole.TEACHER,
                is_active=True
            )
            db.add(teacher_user)
            db.flush()

            teacher_profile = Teacher(
                user_id=teacher_user.id,
                employee_id=emp_id,
                name=name,
                phone="+91-9876543211",
                qualification=qual,
                experience_years=exp,
                join_date=date(2020, 4, 1),
                address="Bhagwanpur, Vaishali, Bihar"
            )
            db.add(teacher_profile)
        db.flush()

        # Get teacher for assignment
        teacher = db.query(Teacher).first()

        # ==================== PARENTS ====================
        print("👪 Creating Parent users...")
        parent_user = User(
            email="parent@slnsvm.com",
            password_hash=demo_password,
            role=UserRole.PARENT,
            is_active=True
        )
        db.add(parent_user)
        db.flush()

        parent_profile = Parent(
            user_id=parent_user.id,
            name="Ramesh Prasad",
            phone="+91-9876543212",
            email="parent@slnsvm.com",
            occupation="Business",
            address="Bhagwanpur, Vaishali, Bihar",
            relation="Father"
        )
        db.add(parent_profile)
        db.flush()

        # ==================== STUDENTS ====================
        print("🎓 Creating Student users...")
        students_data = [
            ("student@slnsvm.com", "Rahul Prasad", "2024001", class_10_a, "A", 1),
            ("student2@slnsvm.com", "Priya Kumari", "2024002", class_10_a, "A", 2),
            ("student3@slnsvm.com", "Amit Kumar", "2024003", class_8_b, "B", 1),
        ]

        for email, name, adm_no, class_obj, section, roll in students_data:
            student_user = User(
                email=email,
                password_hash=demo_password,
                role=UserRole.STUDENT,
                is_active=True
            )
            db.add(student_user)
            db.flush()

            student_profile = Student(
                user_id=student_user.id,
                admission_no=adm_no,
                name=name,
                class_id=class_obj.id if class_obj else None,
                section=section,
                roll_no=roll,
                dob=date(2008, 5, 15),
                gender="Male" if "Kumar" in name or "Rahul" in name else "Female",
                address="Bhagwanpur, Vaishali, Bihar",
                phone="+91-9876543213",
                parent_id=parent_profile.id,
                blood_group="O+"
            )
            db.add(student_profile)

        # ==================== TIMETABLE ====================
        print("📅 Creating Timetable...")
        if class_10_a and teacher and subjects:
            days = [DayOfWeek.MONDAY, DayOfWeek.TUESDAY, DayOfWeek.WEDNESDAY, DayOfWeek.THURSDAY, DayOfWeek.FRIDAY]
            times_schedule = [
                (time(9, 0), time(9, 45)),
                (time(9, 45), time(10, 30)),
                (time(10, 45), time(11, 30)),
                (time(11, 30), time(12, 15)),
                (time(13, 0), time(13, 45)),
                (time(13, 45), time(14, 30)),
            ]

            for day in days:
                for period, (start, end) in enumerate(times_schedule, 1):
                    subject = subjects[period % len(subjects)]
                    timetable_entry = Timetable(
                        class_id=class_10_a.id,
                        day=day,
                        period=period,
                        start_time=start,
                        end_time=end,
                        subject_id=subject.id,
                        teacher_id=teacher.id,
                        room=class_10_a.room_number
                    )
                    db.add(timetable_entry)

        # ==================== NOTICES ====================
        print("📢 Creating Notices...")
        notices_data = [
            ("Annual Day Celebration", "We are pleased to announce the Annual Day celebration on January 26th, 2025. All parents are cordially invited.", "high"),
            ("Winter Vacation Notice", "School will remain closed from December 25th to January 1st for winter vacation.", "medium"),
            ("PTM Announcement", "Parent-Teacher Meeting is scheduled for January 15th, 2025. Please attend to discuss your child's progress.", "high"),
            ("Library Books Return", "All students are requested to return their library books before the winter vacation.", "low"),
        ]

        admin = db.query(Admin).first()
        for title, content, priority in notices_data:
            notice = Notice(
                title=title,
                content=content,
                priority=priority,
                target_role=None,  # All users
                created_by=admin.id if admin else None,
                is_active=True
            )
            db.add(notice)

        # Commit all changes
        db.commit()

        print("\n✅ Database seeded successfully!")
        print("\n" + "="*50)
        print("📋 DEMO CREDENTIALS")
        print("="*50)
        print("\n🔑 Password for all accounts: demo123")
        print("\n👤 Admin Login:")
        print("   Email: admin@slnsvm.com")
        print("\n👨‍🏫 Teacher Logins:")
        print("   Email: teacher@slnsvm.com")
        print("   Email: teacher2@slnsvm.com")
        print("   Email: teacher3@slnsvm.com")
        print("\n👪 Parent Login:")
        print("   Email: parent@slnsvm.com")
        print("\n🎓 Student Logins:")
        print("   Email: student@slnsvm.com")
        print("   Email: student2@slnsvm.com")
        print("   Email: student3@slnsvm.com")
        print("\n" + "="*50)

    except Exception as e:
        print(f"❌ Error seeding database: {e}")
        db.rollback()
        raise
    finally:
        db.close()


if __name__ == "__main__":
    seed_database()
